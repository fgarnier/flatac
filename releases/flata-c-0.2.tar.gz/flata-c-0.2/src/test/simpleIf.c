int main () {
 int i = 5;
 if ( i < 5 ) return 0;
 else i = 0;

 return 0;
}
