#include <stdlib.h>

int main() {
  int i = 0;

  while (i++ < 10) ;
  return 0;
}
