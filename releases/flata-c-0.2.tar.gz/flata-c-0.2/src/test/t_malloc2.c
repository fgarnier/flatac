#include <stdlib.h>

int main ( ) { 
  int* tab = (int*)(malloc(sizeof(int) * 10));

  return 0;
}
