
int not_branch (int a , int b ){

int res;
	res = a+b;
	return (res);

}

int mult (int x, int y){
	
	int res;
	x++;
	y--;
	res = x*y;
	return (res);

}
