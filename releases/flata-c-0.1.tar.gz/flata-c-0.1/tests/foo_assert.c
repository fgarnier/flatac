
void foo_assert (int);


int main (int argc, char **argv){
	foo_assert ( argc );
	return (0);
	
}
