#include <assert.h>


int main (int argc, char ** argv){

	dummy_assert(argc==1);
	exit(0);

}
