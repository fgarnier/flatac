#include <stdio.h>

int main  (int argc, char **argv){
	
	if ( (argc == 3 && argc > 0) ||  (argc == 67 && argc > 16))
	{
	printf  ("Pouet");
	}

	return 0;

}
