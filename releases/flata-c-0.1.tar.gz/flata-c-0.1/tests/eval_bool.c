



int main (int argc, char ** argv){

	int ret=0;
	ret=((argc == 1) || (argc % 2)!=1 );
	return ret;
}
