#include <stdio.h>

int main(int argc, char **argv){

	printf("Valeur revoyée par 3==3: %d, et 3==2: %d \n",3==3, 3==2);
	return(0);
}
