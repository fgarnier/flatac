
int main (int argc, char ** argv){

int a = ((6*7)!=argc)&&(argc>7);
 return (a);


}
