
int skip;
int x[100];
int i,j,n;
int __BLAST_NONDET;

main(){

  j = __BLAST_NONDET;

  for(i = 0; i < 100; i++){
    x[i] = i;
  }
  
  if ( 0 <= j && j < 100){
    if (x[j] != j){
    ERROR: goto ERROR;
    }
  }
}
