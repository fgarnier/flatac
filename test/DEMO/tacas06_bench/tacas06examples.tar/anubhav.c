main(){
  
  int i,j,x,y;
  
  x = i;
  y = j;
  
  while(x != 0){
    x--; y--;
  }
  
  if (i == j && y != 0) {
  ERROR: goto ERROR;
  }
}
