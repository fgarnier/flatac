
int skip;
int x[10];
int i,j,n;

main(){


    for(i = 0; i < n; i++){
      x[i] = 0;
    }

    if ( 0 <= j && j < n){
      if (x[j] != 0){
	ERROR: goto ERROR;
      }
    }

}
