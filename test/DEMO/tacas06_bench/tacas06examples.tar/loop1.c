
int skip;
int x[10];
int i,j,n;

main(){


    for(i = 0; i < n; i++){
      x[i] = i;
    }

    if ( 0 <= j && j < n){
      if (x[j] != j){
	ERROR: goto ERROR;
      }
    }

}
