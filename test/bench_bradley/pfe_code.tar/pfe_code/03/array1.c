int main() {
  int a[4];
  a[0] = 1;
  a[1] = 1;
  a[2] = a[0] + a[1];
  a[3] = a[1] + a[2];
  return 0;
}
